# Simple console app based on Python

# For changing mac address for the interfaces

# How to use

-   execute **run.sh** `./run.sh`, if u don't have permissions try it `chmod -R 777 ./run.sh` or execute `main.py` via `python` -> `python main.py`.
-   enter interface like `en0`, `l0`.
-   enter new mac address, like: `00:11:22:23:24:25`
